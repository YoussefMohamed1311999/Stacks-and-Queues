#include<iostream>
#include <string>
#include<cstdlib>
using namespace std;


class node {
public:
	string info;
	int priority;
	node *next;
};

class PriorityQ {
	private :

		node *head;

	public:

		PriorityQ()
		{
			head = nullptr;
		}

		string enqueue(string value, int priority)
		{
			node *temp;
			node *temp2;

			temp = new node;


			if (head == nullptr || priority < head->priority) {
				temp->info = value;
				temp->priority = priority;
				temp->next = head;
				head = temp;
			}

			else if (head !=nullptr){
				temp2 = head;

				while ((temp2->next != nullptr) && (temp2->next->priority <= priority)) {
					temp2 = temp2->next;
				}
			
				temp->next = temp2->next;
				temp2->next = temp;
			}
		
			return temp->info;
		
		}


		string dequeue()
		{
			if (head != nullptr) {
				node * temp;
				temp = head;
				string TBR = temp->info;
				head = head->next;
				return TBR;
			}
			
			else {
				cout << "nothing to dequeue cause queue is empty" << endl;
			}

		}
};



int main()
{
	PriorityQ pq;
	pq.enqueue("world", 10);
	pq.enqueue("Hello", 5);
	pq.enqueue("say", 1);
	cout<<pq.dequeue()<<" ";
	cout<<pq.dequeue();
	cout << pq.dequeue();
	cout << endl;
}