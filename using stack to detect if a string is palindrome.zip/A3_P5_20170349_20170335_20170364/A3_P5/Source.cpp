#include <iostream>
#include <stack>
#include <string>

using namespace std;

bool isPalindrome(string a)
{
	int Pstrsize = a.size();
	stack<char> Ps;

	reverse(a.begin(), a.end());
	//hena ba2sem l string noseen for later comparison nos fyl stack wy nos gowa l string nafso
	for (int i = 0; i < Pstrsize ; i++) {
		Ps.push(a[i]);
	}


	//hena bacheck howa paldinrome wla la2 lw kan da5elly string fyh ay 7aga
	for (int i=0; i<Pstrsize; i++) {

		//el if btshoof l element ely on top of the stack zy awel element fyl string wla la2 wy hakaza l7ad ma l stack wyl string yefdo
		//bas btemshy 3ala l nos l tany mn l string wy tkarno bl nos el awlany ely et7at fyl stack y3ny mslan abba
		//ab hy5osho fyl stack wy hytshalo mn l string wy l string yb2a ba wy l top of stack hena hyb2a l b wy hnkarno by awel element
		//fyk string ely howa l b fa lw tel3o zay b3d nepop wy ne-erase wy nkaren el elements l fadla wy hakaza
		if (Ps.top() == a[i]) {
			Ps.pop();
		
			//dyh bt2akedly eny 3adeet 3la kol el elements safely wy bema eno md5alsh fyl else wy lw l stack fedy yb2a howa akeed paldinrome
			//3shan nafs l elements etshalet mn l stack fa b2a l size bta3o by zero
			if (Ps.size() == 0) {
				cout << "this word is palindrome" << endl;
				return true;
			}
		}

		//law fy ay wa2t l element ely fyl stack mkansh equal el element ely fyl string msh hyb2a paldinrome
		else {
			cout << "this word is not palindrome" << endl;
			return false;
		}
	}
}


int main()
{
	string x = "abba";
	isPalindrome(x);
	string c = "abbc";
	isPalindrome(c);
}