#include<iostream>
#include<cstdlib>
using namespace std;


template <class T>

class node{
public:
	T info;
	node<T>* next;
};

template <class T>

class mystack {
private:
	node<T> * top;
	int count;
	int mNOE;
public:	
	mystack()
	{
		top = nullptr;
		count = 0;
		mNOE = 0;
	}
	mystack(T value,int noe)
	{
		top = nullptr;
		count = 0;
		mNOE = noe;
		for (int i = 0; i < noe; i++) {
			push(value);
		}

	}
	
	void push(const T &x)
	{

				if (top == nullptr) {
					top = new node<T>;
					top->next = nullptr;
					top->info = x;
					count++;
				}
				else {
					node<T>* temp = new node<T>;
					temp->info = x;
					temp->next = top;
					top = temp;
					count++;
				}
	}
	
	void pop()
	{
		if (top == nullptr)
		{
			cout << "stack is empty";
	}
		else
		{
			cout << top->info << endl;
			node<T>* temp = top;
			top = top->next;
			count--;
			delete(temp);
		}
	}
	
	T& gettop()
	{
		if (top) {
			return top->info;
		}
		else
		{
			cout << "stack is empty";
		}
	}
	
	int size()
	{
		return count;
	}
	~mystack()
	{
		delete top;
	}
};


int main()
{
	mystack<int> s(2,4);
	cout << s.gettop() << endl;
	s.push(5);
	s.push(9);
	s.push(11);
	s.push(10);
	s.pop();
	cout << s.gettop() << endl;
	s.push(20);
	cout << s.gettop() << endl;
	s.push(50);
	cout << s.gettop()<<endl;
	cout << s.size() << endl;
}