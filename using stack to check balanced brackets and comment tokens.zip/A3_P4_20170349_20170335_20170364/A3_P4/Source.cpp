#include <iostream>
#include <stack>
#include<string>

using namespace std;
bool IsValid(string tobeclosed)
{
	stack<char> Bstack;
	char c;


	for (int i = 0; i < tobeclosed.length(); i++) {
		
		if (tobeclosed[i] == '(' || tobeclosed[i] == '[' || tobeclosed[i] == '{') {
			Bstack.push(tobeclosed[i]);
			continue;
		}

		else if (Bstack.empty())
		{
			return false;
		}

		switch (tobeclosed[i]) 
		{
		case ')':
				c = Bstack.top();
				Bstack.push(tobeclosed[i]);
				if ((c == '{' || c == '[' || c == '/') && (tobeclosed[i - 2] != '*')) {
					cout << "the string is invalid as there are brackets or comments that have not been closed" << endl;
					return false;
				}
				break;

		case '}':
				c = Bstack.top();
				Bstack.push(tobeclosed[i]);
				if ((c == '(' || c == '[' || c == '/') && (tobeclosed[i-2] !='*')) {
					cout << "the string is invalid as there are brackets or comments that have not been closed" << endl;
					return false;
				}
				break;
		
		case ']':
				c = Bstack.top();
				Bstack.push(tobeclosed[i]);
				if ((c == '{' || c == '(' || c == '/') && (tobeclosed[i - 2] != '*')) {
					cout << "the string is invalid as there are brackets or comments that have not been closed" << endl;
					return false;
				}
				break;
		
		case '/':
			c = Bstack.top();
			Bstack.push(tobeclosed[i]);
			if ( c=='/' || (tobeclosed[i + 1] != '*'&& tobeclosed[i-1]!='*')) {
				cout<< "the string is invalid as there are brackets or comments that have not been closed" << endl;
				return false;
			}
			break;

		case '*':
			c = Bstack.top();
			Bstack.push(tobeclosed[i]);
			for (int x = i; x < tobeclosed.length(); x++) {
				bool CC = false;
				if (tobeclosed[x] == '*' && tobeclosed[x + 1] == '/') {
					CC = true;
					break;
				}
				else if ((CC == false) && (x == tobeclosed.length() - 1)) {
					cout << "the string is invalid as there are brackets or comments that have not been closed" << endl;
					return false;
				}
			}

			if ((c == '{' || c == '(' || c=='['||c == ')' || c == '}' || c == ']') && ((tobeclosed[i+1] != '/')&&(tobeclosed[i-1]!='/'))) {
				cout << "the string is invalid as there are brackets or comments that have not been closed" << endl;
				return false;
			}
			break;

			
		}
	}
	cout << "the string is valid" << endl;
	return (Bstack.empty());
 }


int main()
{
	string v = "([{}])(){}[]{[]}";
	IsValid(v);


	string x = "({)}";
	IsValid(x);


	string y = "({/*)}]]]]]]}*/})";
	IsValid(y);


	string z = "({/*[][[]]]]]})";
	IsValid(z);

	string s = "[{/*******/}]";
	IsValid(s);
	return 0;
}