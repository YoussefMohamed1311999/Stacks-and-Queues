#include <iostream>
#include <queue>
#include <algorithm>

using namespace std;

class mystack {
	private:
		
		//Reimplement the class for �int� data type	only
		//the queue that will be disguised as a stack. hehe.
		queue<int>SQ;
	
	public:
		
		//int top() � returns the top element.
		int top()
		{
			if (SQ.empty()) {
				cout << "there is nothing in the stack to find" << endl;
			}
			else {
				return SQ.front();
			}
		}
		
		// removes element from the top of the stack by using the queue pop function and by removing the front element of the queue.
		void pop()
		{
			if (SQ.empty()) {
				cout << "there is nothing in the stack to pop"<<endl;
			}
			else {
				cout << SQ.front() << endl;
				SQ.pop();
			}
		}

		//adds an element to the top of the stack by adding it to the front of the queue.
		void push(int value)
		{
			int SOS = SQ.size();
			SQ.push(value);
			for (int i = 0; i < SOS; i++) {
				//pushing the element which we first entered in again in order to have a queue ordered like a stack
				SQ.push(SQ.front());
				// the pop removes the element which first entered the queue so that means the element inserted after it
				//becomes the front of the queue as if it is the top of the stack
				SQ.pop();
			}

		}
};

int main()
{
	mystack s;
	s.push(10);
	s.push(20);
	cout << s.top()<<endl;
	s.pop();
	cout<<s.top()<<endl;
	s.pop();
	s.top();
	s.pop();
}
